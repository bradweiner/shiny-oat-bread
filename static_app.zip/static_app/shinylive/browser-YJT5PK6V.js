// Shinylive 0.9.1
// Copyright 2024 Posit, PBC
import{c as t}from"./chunk-CALE5Q57.js";var o=t((r,e)=>{e.exports=function(){throw new Error("ws does not work in the browser. Browser clients must use the native WebSocket object")}});export default o();
